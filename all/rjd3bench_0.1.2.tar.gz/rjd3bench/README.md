# rjd3bench
Temporal disaggregation and benchmarking
