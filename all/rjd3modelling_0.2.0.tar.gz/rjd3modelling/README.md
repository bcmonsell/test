
<!-- README.md is generated from README.Rmd. Please edit that file -->

# rjd3modelling

## Installation

``` r
# Install development version from GitHub
# install.packages("remotes")
remotes::install_github("palatej/rjd3toolkit")
remotes::install_github("palatej/rjd3modelling")
```
