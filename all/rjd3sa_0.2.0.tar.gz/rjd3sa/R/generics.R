#' Title
#'
#' @param x
#' @param ...
#'
#' @return
#' @export
#'
#' @examples
sa.preprocessing<-function(x, ...){
  UseMethod("sa.preprocessing")
}


#' Title
#'
#' @param x
#' @param ...
#'
#' @return
#' @export
#'
#' @examples
sa.decomposition<-function(x, ...){
  UseMethod("sa.decomposition")
}

