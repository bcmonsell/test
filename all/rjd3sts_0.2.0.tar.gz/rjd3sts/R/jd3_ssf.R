#' @include utils.R
NULL

SSF<-'JD3_Ssf'
EQUATION<-'JD3_SsfEquation'
LOADING<-'JD3_SsfLoading'
MODELESTIMATION<-'JD3_SsfModelEstimation'
MODEL<-'JD3_SsfModel'
STATEBLOCK<-'JD3_SsfStateBlock'

#' Title
#'
#' @param equation 
#' @param item 
#' @param coeff 
#' @param fixed 
#' @param loading 
#'
#' @return
#' @export
#'
#' @examples
add.equation<-function(equation, item, coeff=1, fixed=TRUE, loading=NULL){
  if (! is(equation, EQUATION))
    stop("Not an equation")
  if (is.null(loading))
    .jcall(equation$internal, "V", "add", item, coeff, as.logical(fixed), .jnull("jdplus/ssf/ISsfLoading"))
  else if (is(loading, LOADING))
    .jcall(equation$internal, "V", "add", item, coeff, as.logical(fixed), loading$internal)
  else
    stop("Not a loading")
}


#' Title
#'
#' @param object 
#' @param obs 
#' @param pos 
#' @param loading 
#' @param stdev 
#'
#' @return
#' @export
signal<-function(object, obs=1, pos=NULL, loading=NULL, stdev=F){
  if (! is(object, MODELESTIMATION))
    stop("Not a model estimation")
  if ( is.jnull(object$internal)){
    return (NULL)
  }else{
    if (! is.null(loading)){
      if (stdev){
        return (.jcall(object$internal, "[D", "stdevSignal", rjd3toolkit:::matrix_r2jd(loading)))
      }else{
        return (.jcall(object$internal, "[D", "signal", rjd3toolkit:::matrix_r2jd(loading)))
      }
    }else{
      if (is.null(pos))
        jpos<-.jnull("[I")
      else
        jpos<-.jarray(as.integer(pos-1))
      if (stdev){
        return (.jcall(object$internal, "[D", "stdevSignal", as.integer(obs-1), jpos))
      }else{
        return (.jcall(object$internal, "[D", "signal", as.integer(obs-1), jpos))
      }
    }
  }
}

#' Title
#'
#' @param object 
#' @param m 
#' @param pos 
#' @param stdev 
#'
#' @return
#' @export
#'
#' @examples
msignal<-function(object, m, pos=NULL, stdev=F){
  if (! is(object, MODELESTIMATION))
    stop("Not a model estimation")
  if ( is.jnull(object$internal)){
    return (NULL)
  }
  if (! is.matrix(m)){
    stop("Invalid matrix")
  }else{
    if (is.null(pos))
      jpos<-.jnull("[I")
    else{
      if (length(pos) != dim(m)[2])
        stop("Invalid input")
      jpos<-.jarray(as.integer(pos-1))
    }
    jm=rjd3toolkit:::matrix_r2jd(m)
    if (stdev){
      return (.jcall(object$internal, "[D", "stdevSignal", jm, jpos))
    }else{
      return (.jcall(object$internal, "[D", "signal", jm, jpos))
    }
  }
}

#' Title
#'
#' @param object 
#' @param obs 
#'
#' @return
#' @export
#'
#' @examples
loading<-function(object, obs=1){
  if (! is(object, MODELESTIMATION))
    stop("Not a model estimation")
  if ( is.jnull(object$internal)){
    return
  }else{
      jm<-.jcall(object$internal, "Ldemetra/math/matrices/Matrix;", "loading", as.integer(obs-1))
      return (rjd3toolkit:::matrix_jd2r(jm))
  }
}

#' Title
#'
#' @param model 
#' @param item 
#'
#' @return
#' @export
#'
#' @examples
add<-function(model, item){
  if (! is(model, MODEL))
    stop("Not a model")
  if ( is.jnull(model$internal))
    return (NULL)
  if (is(item, EQUATION) || is(item, STATEBLOCK)){
    if (! is.jnull(item$internal))
      .jcall(model$internal, "V", "add", item$internal )
  }else{
    stop("Invalid item")
  }
}

#' Title
#'
#' @param model 
#' @param data 
#' @param marginal 
#' @param concentrated 
#' @param initialization 
#' @param optimizer 
#' @param precision 
#' @param initialParameters 
#'
#' @return
#' @export
#'
#' @examples
estimate<-function(model, data, marginal=F, concentrated=T,
              initialization=c("Augmented_Robust", "Diffuse", "SqrtDiffuse", "Augmented", "Augmented_NoCollapsing"), optimizer=c("LevenbergMarquardt", "MinPack", "BFGS", "LBFGS"), precision=1e-15, initialParameters=NULL){
  initialization=match.arg(initialization)
  optimizer=match.arg(optimizer)
  if (! is(model, MODEL))
    stop("Not a model")
  if ( is.jnull(model$internal) ){
    return(NULL)
  }else{
    jparams<-.jnull("[D")
    if (! is.null(initialParameters))
      jparams<-.jarray(initialParameters)
    jdata<-rjd3toolkit:::matrix_r2jd(data)
    jrslt<-.jcall("rssf/CompositeModels", "Lrssf/CompositeModels$Results;", "estimate",model$internal, jdata, marginal, concentrated, initialization, optimizer, precision, jparams)
    return (rjd3toolkit:::jd3Object(jrslt, MODELESTIMATION, T))
  }
}

compute<-function(model, data, parameters, marginal=FALSE, concentrated=TRUE){
  if (! is(model, MODEL))
    stop("Not a model")
  if ( is.jnull(model$internal) ){
    return(NULL)
  }else{
    jdata<-rjd3toolkit:::matrix_r2jd(data)
    jrslt<-.jcall("rssf/CompositeModels", "Lrssf/CompositeModels$Results;", "compute", model$internal, jdata, .jarray(parameters), marginal, concentrated)
    return(rjd3toolkit:::jd3Object(jrslt, MODELESTIMATION, T))
  }
}



#' Title
#'
#' @param name 
#' @param ar 
#' @param fixedar 
#' @param variance 
#' @param fixedvariance 
#' @param nlags 
#' @param zeroinit 
#'
#' @return
#' @export
#'
#' @examples
ar<-function(name, ar, fixedar=FALSE, variance=.01, fixedvariance=FALSE, nlags=0, zeroinit=FALSE){

  jrslt<-.jcall("jdplus/msts/AtomicModels", "Ljdplus/msts/StateItem;", "ar", name, .jarray(ar), fixedar, variance, fixedvariance, as.integer(nlags), zeroinit)
  return (rjd3toolkit:::jd3Object(jrslt, STATEBLOCK))
}

#' Title
#'
#' @param name 
#' @param factor 
#' @param period 
#' @param fixed 
#' @param variance 
#' @param fixedvariance 
#'
#' @return
#' @export
#'
#' @examples
cycle<-function(name, factor=.9, period=60, fixed=F, variance=.01, fixedvariance=FALSE){
  jrslt<-.jcall("jdplus/msts/AtomicModels", "Ljdplus/msts/StateItem;", "cycle", name, factor, period, fixed, variance, fixedvariance)
  return (rjd3toolkit:::jd3Object(jrslt, STATEBLOCK))
}

#' Title
#'
#' @param name 
#' @param period 
#' @param harmonics 
#' @param variance 
#' @param fixedvariance 
#'
#' @return
#' @export
#'
#' @examples
periodic<-function(name, period, harmonics, variance=.01, fixedvariance=FALSE){
  jrslt<-.jcall("jdplus/msts/AtomicModels", "Ljdplus/msts/StateItem;", "periodicComponent", name, period, .jarray(as.integer(harmonics)), variance, fixedvariance)
  return (rjd3toolkit:::jd3Object(jrslt, STATEBLOCK))
}


#' Title
#'
#' @param name 
#' @param ar 
#' @param fixedar 
#' @param variance 
#' @param fixedvariance 
#' @param nlags 
#' @param nfcasts 
#'
#' @return
#' @export
#'
#' @examples
ar2<-function(name, ar, fixedar=FALSE, variance=.01, fixedvariance=FALSE, nlags=0, nfcasts=0){
  jrslt<-.jcall("jdplus/msts/AtomicModels", "Ljdplus/msts/StateItem;", "ar", name, .jarray(ar), fixedar, variance, fixedvariance, as.integer(nlags), as.integer(nfcasts))
  return (rjd3toolkit:::jd3Object(jrslt, STATEBLOCK))
}




#' Title
#'
#' @param name 
#' @param ar 
#' @param fixedar 
#' @param lag 
#' @param zeroinit 
#'
#' @return
#' @export
#'
#' @examples
sae<-function(name, ar, fixedar=FALSE, lag=1, zeroinit=FALSE){
  jrslt<-.jcall("jdplus/msts/AtomicModels", "Ljdplus/msts/StateItem;", "sae", name, .jarray(ar), fixedar, as.integer(lag), zeroinit)
  return (rjd3toolkit:::jd3Object(jrslt, STATEBLOCK))
}

#' Title
#'
#' @param name 
#' @param nwaves 
#' @param ar 
#' @param fixedar 
#' @param lag 
#'
#' @return
#' @export
#'
#' @examples
msae<-function(name, nwaves, ar, fixedar=TRUE, lag=1){
  jrslt<-.jcall("jdplus/msts/AtomicModels", "Ljdplus/msts/StateItem;", "waveSpecificSurveyError", name, as.integer(nwaves), rjd3toolkit:::matrix_r2jd(ar), fixedar, as.integer(lag))
  return (rjd3toolkit:::jd3Object(jrslt, STATEBLOCK))
}

#' Title
#'
#' @param name 
#' @param vars 
#' @param fixedvars 
#' @param ar 
#' @param fixedar 
#' @param lag 
#'
#' @return
#' @export
#'
#' @examples
msae2<-function(name, vars, fixedvars=F, ar, fixedar=T, lag=1){
  jrslt<-.jcall("jdplus/msts/AtomicModels", "Ljdplus/msts/StateItem;", "waveSpecificSurveyError", name, vars, fixedvars, rjd3toolkit:::matrix_r2jd(ar), fixedar, as.integer(lag))
  return (rjd3toolkit:::jd3Object(jrslt, STATEBLOCK))
}

#' Title
#'
#' @param name 
#' @param vars 
#' @param fixedvars 
#' @param ar 
#' @param fixedar 
#' @param k 
#' @param lag 
#'
#' @return
#' @export
#'
#' @examples
msae3<-function(name, vars, fixedvars=F, ar, fixedar=T, k, lag=1){
  jrslt<-.jcall("jdplus/msts/AtomicModels", "Ljdplus/msts/StateItem;", "waveSpecificSurveyError", name, vars, fixedvars, .jarray(ar), fixedar, rjd3toolkit:::matrix_r2jd(k), as.integer(lag))
  return (rjd3toolkit:::jd3Object(jrslt, STATEBLOCK))
}

#' Title
#'
#' @param name 
#' @param variance 
#' @param fixed 
#' @param initial 
#'
#' @return
#' @export
#'
#' @examples
locallevel<-function(name, variance=.01, fixed=FALSE, initial=NaN){
  jrslt<-.jcall("jdplus/msts/AtomicModels", "Ljdplus/msts/StateItem;", "localLevel", name, variance, fixed, initial)
  return (rjd3toolkit:::jd3Object(jrslt, STATEBLOCK))
}


#' Title
#'
#' @param name 
#' @param levelVariance 
#' @param slopevariance 
#' @param fixedLevelVariance 
#' @param fixedSlopeVariance 
#'
#' @return
#' @export
#'
#' @examples
locallineartrend<-function(name, levelVariance=.01, slopevariance=.01, fixedLevelVariance=FALSE, fixedSlopeVariance=FALSE ){
  jrslt<-.jcall("jdplus/msts/AtomicModels", "Ljdplus/msts/StateItem;", "localLinearTrend", name, levelVariance, slopevariance, fixedLevelVariance, fixedSlopeVariance)
  return (rjd3toolkit:::jd3Object(jrslt, STATEBLOCK))
}

#' Title
#'
#' @param name 
#' @param period 
#' @param type 
#' @param variance 
#' @param fixed 
#'
#' @return
#' @export
#'
#' @examples
seasonal<-function(name, period, type=c("Trigonometric", "Crude", "HarrisonStevens", "Dummy"), variance=.01, fixed=FALSE){
  type=match.arg(type)
  jrslt<-.jcall("jdplus/msts/AtomicModels", "Ljdplus/msts/StateItem;", "seasonalComponent", name, type, as.integer(period), variance, fixed)
  return (rjd3toolkit:::jd3Object(jrslt, STATEBLOCK))
}

#' Title
#'
#' @param name 
#' @param variance 
#' @param fixed 
#'
#' @return
#' @export
#'
#' @examples
noise<-function(name, variance=.01, fixed=FALSE){
  jrslt<-.jcall("jdplus/msts/AtomicModels", "Ljdplus/msts/StateItem;", "noise", name, variance, fixed)
  return (rjd3toolkit:::jd3Object(jrslt, STATEBLOCK))
}

#' Title
#'
#' @param name 
#' @param std 
#' @param scale 
#' @param fixed 
#'
#' @return
#' @export
#'
#' @examples
varnoise<-function(name, std, scale=1, fixed=FALSE){
  jrslt<-.jcall("jdplus/msts/AtomicModels", "Ljdplus/msts/StateItem;", "noise", name, as.double(std), scale, fixed)
  return (rjd3toolkit:::jd3Object(jrslt, STATEBLOCK))
}

#' Title
#'
#' @param name 
#' @param std 
#' @param scale 
#' @param fixed 
#' @param initial 
#'
#' @return
#' @export
#'
#' @examples
varlocallevel<-function(name, std, scale=1, fixed=FALSE, initial=NaN){
  jrslt<-.jcall("jdplus/msts/AtomicModels", "Ljdplus/msts/StateItem;", "localLevel", name, as.double(std), scale, fixed, initial)
  return (rjd3toolkit:::jd3Object(jrslt, STATEBLOCK))
}

#' Title
#'
#' @param name 
#' @param lstd 
#' @param sstd 
#' @param levelScale 
#' @param slopeScale 
#' @param fixedLevelScale 
#' @param fixedSlopeScale 
#'
#' @return
#' @export
#'
#' @examples
varlocallineartrend<-function(name, lstd, sstd=NULL, levelScale=1, slopeScale=1, fixedLevelScale=FALSE, fixedSlopeScale=FALSE ){
  
  if (is.null(sstd)){
    jsstd<-.jnull("[D")
  }else{
    jsstd<-.jarray(sstd)
  }
  jrslt<-.jcall("jdplus/msts/AtomicModels", "Ljdplus/msts/StateItem;", "localLinearTrend", name, lstd, jsstd, levelScale, slopeScale,
                fixedLevelScale, fixedSlopeScale)
  return (rjd3toolkit:::jd3Object(jrslt, STATEBLOCK))
}

#' Title
#'
#' @param name 
#' @param period 
#' @param type 
#' @param std 
#' @param scale 
#' @param fixed 
#'
#' @return
#' @export
#'
#' @examples
varseasonal<-function(name, period, type=c("Trigonometric", "Crude", "HarrisonStevens", "Dummy"), std, scale=1, fixed=FALSE){
  
  type=match.arg(type)
  jrslt<-.jcall("jdplus/msts/AtomicModels", "Ljdplus/msts/StateItem;", "seasonalComponent", name, type, as.integer(period), as.double(std), scale, fixed)
  
  
  return (rjd3toolkit:::jd3Object(jrslt, STATEBLOCK))
}

#' Title
#'
#' @return
#' @export
#'
#' @examples
model<-function(){
  jrslt<-.jnew("jdplus/msts/CompositeModel")
  return (rjd3toolkit:::jd3Object(jrslt, MODEL))
}

#' Title
#'
#' @param name 
#' @param variance 
#' @param fixed 
#'
#' @return
#' @export
#'
#' @examples
equation<-function(name, variance=0, fixed=T){
  jrslt<-.jnew("jdplus/msts/ModelEquation", name, variance, fixed)
  return (rjd3toolkit:::jd3Object(jrslt, EQUATION))
}

#' Title
#'
#' @param pos 
#' @param weights 
#'
#' @return
#' @export
#'
#' @examples
loading<-function(pos=NULL, weights=NULL){
  if (is.null(pos)){	
    jrslt<-.jcall("jdplus/ssf/implementations/Loading", "Ljdplus/ssf/ISsfLoading;", "fromPosition", as.integer(0))
    return (rjd3toolkit:::jd3Object(jrslt, LOADING))
  }
  else if (length(pos) == 1){ 
    if (is.null(weights)){
      jrslt<-.jcall("jdplus/ssf/implementations/Loading", "Ljdplus/ssf/ISsfLoading;", "fromPosition", as.integer(pos))
    }else{
      if (length(pos) != length(weights)){
        return (NULL)
      }
      jrslt<-.jcall("jdplus/ssf/implementations/Loading", "Ljdplus/ssf/ISsfLoading;", "from", as.integer(pos), weights[1])
    }
    return (rjd3toolkit:::jd3Object(jrslt, LOADING))
  }else{
    if (is.null(weights))
      jrslt<-.jcall("jdplus/ssf/implementations/Loading", "Ljdplus/ssf/ISsfLoading;", "fromPositions", as.integer(pos))
    else{
      if (length(pos) != length(weights))
        return (NULL)
      jrslt<-.jcall("jdplus/ssf/implementations/Loading", "Ljdplus/ssf/ISsfLoading;", "from", as.integer(pos), weights)
    }
    return (rjd3toolkit:::jd3Object(jrslt, LOADING))
  }
}

#' Title
#'
#' @param pos 
#' @param weights 
#'
#' @return
#' @export
#'
#' @examples
varloading<-function(pos, weights){
  if (is.null(pos)){
    jl<-.jcall("jdplus/ssf/implementations/Loading", "Ljdplus/ssf/ISsfLoading;", "fromPosition", as.integer(0))
  }
  else if (length(pos) == 1){
    jl<-.jcall("jdplus/ssf/implementations/Loading", "Ljdplus/ssf/ISsfLoading;", "fromPosition", as.integer(pos))
  }else{
    jl<-.jcall("jdplus/ssf/implementations/Loading", "Ljdplus/ssf/ISsfLoading;", "fromPositions", as.integer(pos))
  }
  jrslt<-.jcall("jdplus/ssf/implementations/Loading", "Ljdplus/ssf/ISsfLoading;", "rescale", jl, as.numeric(weights))
  return (rjd3toolkit:::jd3Object(jrslt, LOADING))
}

#' Title
#'
#' @param length 
#'
#' @return
#' @export
#'
#' @examples
loading_sum<-function(length=0){
  if (length == 0)
    jrslt<-.jcall("jdplus/ssf/implementations/Loading", "Ljdplus/ssf/ISsfLoading;", "sum")
  else
    jrslt<-.jcall("jdplus/ssf/implementations/Loading", "Ljdplus/ssf/ISsfLoading;", "createPartialSum", as.integer(length))
  return (rjd3toolkit:::jd3Object(jrslt, LOADING))
}

#' Title
#'
#' @param period 
#' @param startpos 
#'
#' @return
#' @export
#'
#' @examples
loading_cyclical<-function(period, startpos){
  jrslt<-.jcall("jdplus/ssf/implementations/Loading", "Ljdplus/ssf/ISsfLoading;", "cyclical", as.integer(period), as.integer(startpos-1))
  return (rjd3toolkit:::jd3Object(jrslt, LOADING))
}

#' Title
#'
#' @param period 
#' @param startpos 
#'
#' @return
#' @export
#'
#' @examples
loading_periodic<-function(period, startpos){
  jrslt<-.jcall("jdplus/ssf/implementations/Loading", "Ljdplus/ssf/ISsfLoading;", "periodic", as.integer(period), as.integer(startpos-1))
  return (rjd3toolkit:::jd3Object(jrslt, LOADING))
}

#' Title
#'
#' @param initialization 
#' @param dynamics 
#' @param measurement 
#'
#' @return
#' @export
#'
#' @examples
ssf<-function(initialization, dynamics, measurement){
  jrslt<-.jcall("rssf/Ssf", "Ljdplus/ssf/univariate/Issf;", "of", initialization$internal, dynamics$internal, measurement$internal)
  return (rjd3toolkit:::jd3Object(jrslt, SSF, T))
}

#' Title
#'
#' @param name 
#' @param ar 
#' @param diff 
#' @param ma 
#' @param var 
#' @param fixed 
#'
#' @return
#' @export
#'
#' @examples
arima<-function(name, ar, diff, ma, var=1, fixed =FALSE){
  jrslt<-.jcall("jdplus/msts/AtomicModels", "Ljdplus/msts/StateItem;", "arima", name, as.double(ar), as.double(diff), as.double(ma), var, fixed)
  return (rjd3toolkit:::jd3Object(jrslt, STATEBLOCK))
}


#' Title
#'
#' @param name 
#' @param ar 
#' @param fixedar 
#' @param ma 
#' @param fixedma 
#' @param var 
#' @param fixedvar 
#'
#' @return
#' @export
#'
#' @examples
arma<-function(name, ar, fixedar=F, ma, fixedma=F, var=1, fixedvar =FALSE){
  jrslt<-.jcall("jdplus/msts/AtomicModels", "Ljdplus/msts/StateItem;", "arma", name, as.double(ar), fixedar,
                as.double(ma), fixedma, var, fixedvar)
  return (rjd3toolkit:::jd3Object(jrslt, STATEBLOCK))
}

#' Title
#'
#' @param name 
#' @param period 
#' @param orders 
#' @param seasonal 
#' @param parameters 
#' @param fixedparameters 
#' @param var 
#' @param fixedvariance 
#'
#' @return
#' @export
#'
#' @examples
sarima<-function(name, period, orders, seasonal, parameters=NULL, fixedparameters=FALSE, var=1, fixedvariance =FALSE){
  if (is.null(parameters))
    jp<-.jnull("[D")
  else
    jp<-.jarray(parameters)
  jrslt<-.jcall("jdplus/msts/AtomicModels", "Ljdplus/msts/StateItem;", "sarima", name, as.integer(period), as.integer(orders), as.integer(seasonal), jp, fixedparameters, var, fixedvariance)
  return (rjd3toolkit:::jd3Object(jrslt, STATEBLOCK))
}

#' Title
#'
#' @param name 
#' @param core 
#' @param period 
#' @param start 
#'
#' @return
#' @export
#'
#' @examples
cumul<-function(name, core, period, start=0){
  jrslt<-.jcall("jdplus/msts/DerivedModels", "Ljdplus/msts/StateItem;", "cumulator", name, core$internal
                , as.integer(period), as.integer(start))
  return (rjd3toolkit:::jd3Object(jrslt, STATEBLOCK))
}

#' Title
#'
#' @param name 
#' @param components 
#'
#' @return
#' @export
#'
#' @examples
aggregation<-function(name, components){
  if(!is.list(components) || length(components)<2 ) {
    stop("incorrect argument, components should be a list of at least 2 items")}
  plist<-list()
  for (i in 1:length(components)){
    plist[[i]]<-components[[i]]$internal
  }
  jcmps<-.jarray(plist, contents.class = "jdplus/msts/StateItem")
  jrslt<-.jcall("jdplus/msts/DerivedModels", "Ljdplus/msts/StateItem;", "aggregation", name, jcmps)
  return (rjd3toolkit:::jd3Object(jrslt, STATEBLOCK))
}

#' Title
#'
#' @param name 
#' @param x 
#' @param var 
#' @param fixed 
#'
#' @return
#' @export
#'
#' @examples
reg<-function(name, x, var=NULL, fixed=F){
  
  if (is.null(var)){
    jrslt<-.jcall("jdplus/msts/AtomicModels", "Ljdplus/msts/StateItem;", "regression", name, rjd3toolkit:::matrix_r2jd(x))
  }else{
    jrslt<-.jcall("jdplus/msts/AtomicModels", "Ljdplus/msts/StateItem;", "timeVaryingRegression", name, rjd3toolkit:::matrix_r2jd(x), as.numeric(var), fixed)
  }
  return (rjd3toolkit:::jd3Object(jrslt, STATEBLOCK))
}

#' Title
#'
#' @param name 
#' @param x Regression variable. Numerics 
#' @param stderr Standard error of the innovations of the coefficient (1 in extrapolation)
#' @param scale Scaling factor
#' @param fixed Fixed scaling factor
#'
#' @return
#' @export
#'
#' @examples
#'  x<-rjd3toolkit::retail$BookStores
#'  std<-rep(1, length(x))
#'  std[c(20, 50, 150)]<-5
#'  v<-varreg("vx", x, std, 0.1)
varreg<-function(name, x, stderr, scale=1, fixed=F){
  
   jrslt<-.jcall("jdplus/msts/AtomicModels", "Ljdplus/msts/StateItem;", "timeVaryingRegression", name
                 , as.numeric(x), as.numeric(stderr), as.numeric(scale), fixed)
   return (rjd3toolkit:::jd3Object(jrslt, STATEBLOCK))
}

#' Title
#'
#' @param name 
#' @param period 
#' @param start 
#' @param length 
#' @param groups 
#' @param contrast 
#' @param variance 
#' @param fixed 
#'
#' @return
#' @export
#'
#' @examples
td<-function(name, period, start, length, groups=c(1,2,3,4,5,6,0), contrast=TRUE, variance=1, fixed=FALSE){
  jdomain<-rjd3toolkit:::tsdomain_r2jd(period, startYear = start[1], startPeriod = start[2], length = length)
  jrslt<-.jcall("jdplus/msts/AtomicModels", "Ljdplus/msts/StateItem;", "tdRegression", name, jdomain, as.integer(groups), contrast, variance, fixed)
  return (rjd3toolkit:::jd3Object(jrslt, STATEBLOCK))
}

#' Title
#'
#' @param rslt 
#'
#' @return
#' @export
#'
#' @examples
smoothedstates<-function(model){
  if (! is(model, MODELESTIMATION))
    stop("Not a model")
  if ( is.jnull(model$internal) ){
    return(NULL)
  }
  return(rjd3toolkit::result(model, "ssf.smoothing.states"))
}

#' Title
#'
#' @param rslt 
#'
#' @return
#' @export
#'
#' @examples
smoothedstatesstdev<-function(rslt){
  if (! is(rslt, MODELESTIMATION))
    stop("Not a model")
  if ( is.jnull(rslt$internal) ){
    return(NULL)
  }
  return(sqrt(rjd3toolkit::result(rslt, "ssf.smoothing.vstates")))
}

#' Title
#'
#' @param rslt 
#'
#' @return
#' @export
#'
#' @examples
filteredstates<-function(rslt){
  if (! is(rslt, MODELESTIMATION))
    stop("Not a model")
  if ( is.jnull(rslt$internal) ){
    return(NULL)
  }
  return(rjd3toolkit::result(rslt, "ssf.filtered.states"))
}

#' Title
#'
#' @param rslt 
#'
#' @return
#' @export
#'
#' @examples
filteredstatesstdev<-function(rslt){
  if (! is(rslt, MODELESTIMATION))
    stop("Not a model")
  if ( is.jnull(rslt$internal) ){
    return(NULL)
  }
  return(sqrt(rjd3toolkit::result(rslt, "ssf.filtered.vstates")))
}

#' Title
#'
#' @param rslt 
#'
#' @return
#' @export
#'
#' @examples
filteringstatesstdev<-function(rslt){
  if (! is(rslt, MODELESTIMATION))
    stop("Not a model")
  if ( is.jnull(rslt$internal) ){
    return(NULL)
  }
  return(sqrt(rjd3toolkit::result(rslt, "ssf.filtering.vstates")))
}

#' Title
#'
#' @param rslt 
#'
#' @return
#' @export
#'
#' @examples
filteringstates<-function(rslt){
  if (! is(rslt, MODELESTIMATION))
    stop("Not a model")
  if ( is.jnull(rslt$internal) ){
    return(NULL)
  }
  return(rjd3toolkit::result(rslt, "ssf.filtering.states"))
}

