#' @importFrom rJava .jpackage .jcall .jnull .jarray .jevalArray .jcast .jcastToArray .jinstanceof is.jnull .jnew .jclass
#' @import RProtoBuf
#' @importFrom stats frequency is.ts pt start ts
#' @importFrom rjd3toolkit result dictionary    
NULL
