
<!-- README.md is generated from README.Rmd. Please edit that file -->

# rjd3toolkit

## Installation

``` r
remotes::install_github("palatej/rjd3toolkit")
```
