#' Model diagnostic summary from a list
#'
#' Generate a summary of model diagnostics from a list of \code{seas} objects series 
#'
#' @param seas_obj_list list of \code{seas} objects generated from a call of \code{seas} on a single time series 
#' @param add_aicc logical scalar; add AICC value to the summary
#' @param add_norm logical scalar; add normality statistics to the summary
#' @param add_auto_out logical scalar; add identified automatic outliers to the summary
#' @param add_spec logical scalar; add test for spectral peaks to the summary
#' @param save_summary logical scalar; save the summary matrix in a separate Excel file
#' @param save_file character string; file name for saving summary matrix
#' @param save_append logical scalar; if TRUE, append the sheet to the Excel file, otherwise overwrite the sheet. Default is TRUE
#' @param save_sheetname character string; sheet name used for the Excel file
#' @return vector of model diagnostics for a given series
#' @examples
#'  xt_lauto <- seasonal::seas(xt_data_list, slidingspans = "", transform.function = "log", 
#'                             x11.seasonalma = "msr",
#'                             arima.model = "(0 1 1)(0 1 1)",
#'                             forecast.maxlead=36, check.print = c( "pacf", "pacfplot" ))
#'  xt_diag <- all_model_diag_list(xt_lauto, add_aicc = TRUE, 
#'                         add_norm = TRUE, add_auto_out = TRUE, 
#'                         add_spec = TRUE)
#' @export
all_model_diag_list <- function(seas_obj_list, add_aicc = FALSE, add_norm = FALSE, add_auto_out = FALSE, 
    add_spec = FALSE, save_summary = FALSE, save_file = "this_excel_file.xlsx", save_append = TRUE, save_sheetname = "diag") {
    # Author: Brian C. Monsell (OEUS) Version 3.4, 3/35/2022
    
    # check if a value is specified for \code{seas_obj_list}
    if (is.null(seas_obj_list)) {
        stop("must specify a list of seasonal objects")
    } else {
        if (!is.list(seas_obj_list)) {
            stop("must specify a list")
        }
    }
    
    # get ARIMA Model
    this_model <- lapply(seas_obj_list, function(x) try(seasonal::udg(x, "arimamdl")))
    
    # get number of regressors
    this_nreg <- lapply(seas_obj_list, function(x) try(seasonal::udg(x, "nreg")))
    
    # add automatic outliers, if specified
    if (add_auto_out) {
        this_autoout <- lapply(seas_obj_list, function(x) try(seasonal::udg(x, "autoout")))
        this_autoreg <- lapply(seas_obj_list, function(x) try(get_auto_outlier_string(x)))
    }
    
    # add aicc, if specified
    if (add_aicc) {
        this_aicc <- lapply(seas_obj_list, function(x) try(seasonal::udg(x, "aicc")))
    }
    
    # generate residual ACF test result
    this_acf_test <- lapply(seas_obj_list, function(x) try(acf_test(x, return_this = "why")))
    
    # generate seasonality test using QS
    this_seasonal_test <- lapply(seas_obj_list, function(x) try(qs_seasonal_test(x, test_full = TRUE, 
        test_span = FALSE, return_this = "why")))
    
    
    
    # create summary matrix by binding different test results
    # set dimensions name for summary matrix
    this_model_summary <- 
        cbind(unlist(this_model), unlist(this_nreg), unlist(this_acf_test), unlist(this_seasonal_test))
    dimnames(this_model_summary)[[1]] <- names(this_model)
    dimnames(this_model_summary)[[2]] <- 
        c("ARIMA Model", "Number of Reg", "ACF Test", "Seasonal (QS)")
    
    # generate seasonality test using spectral peaks
    if (add_spec) {
        old_dimnames <- dimnames(this_model_summary)[[2]]
        this_spec_peak_test <- lapply(seas_obj_list, function(x) 
            try(spec_peak_test(x, this_spec = "spcori", return_this = "why")))
        this_model_summary <- cbind(this_model_summary, unlist(this_spec_peak_test))
        dimnames(this_model_summary)[[2]] <- c(old_dimnames, "Spec Peaks")
    }
    
    
    # add aicc to summary matrix, if specified
    if (add_aicc) {
        old_dimnames <- dimnames(this_model_summary)[[2]]
        this_model_summary <- cbind(this_model_summary, unlist(this_aicc))
        dimnames(this_model_summary)[[2]] <- c(old_dimnames, "AICC")
    }
    
    # generate normality statistics, if specified, and add to summary matrix
    if (add_norm) {
        old_dimnames <- dimnames(this_model_summary)[[2]]
        this_a <- lapply(seas_obj_list, function(x) try(get_norm_stat(x, "a")))
        this_a_test <- lapply(seas_obj_list, function(x) try(norm_test(x, "a")))
        this_kurtosis <- lapply(seas_obj_list, function(x) try(get_norm_stat(x, "kurtosis")))
        this_kurtosis_test <- lapply(seas_obj_list, function(x) try(norm_test(x, "kurtosis")))
        this_skewness <- lapply(seas_obj_list, function(x) try(get_norm_stat(x, "skewness")))
        this_skewness_test <- lapply(seas_obj_list, function(x) try(norm_test(x, "skewness")))
        this_model_summary <- cbind(this_model_summary, replace_na(unlist(this_a)), 
                                    replace_na(unlist(this_a_test)), 
                                    replace_na(unlist(this_kurtosis)), 
                                    replace_na(unlist(this_kurtosis_test)), 
                                    replace_na(unlist(this_skewness)), 
                                    replace_na(unlist(this_skewness_test)))
        dimnames(this_model_summary)[[2]] <- c(old_dimnames, "Gearys_a", "a_test", "Kurtosis", "Kurtosis_test", 
            "Skewness", "Skewness_test")
        
    }
    
    # add automatic outliers to summary matrix, if specified
    if (add_auto_out) {
        old_dimnames <- dimnames(this_model_summary)[[2]]
        this_model_summary <- cbind(this_model_summary, unlist(this_autoout), unlist(this_autoreg))
        dimnames(this_model_summary)[[2]] <- c(old_dimnames, "Number of AutoOut", "Auto Outliers")
    }
    
    # save summary matrix to excel file, if specified
    if (save_summary) {
        xlsx::write.xlsx(as.data.frame(this_model_summary), file = save_file, append = save_append, 
            sheetName = save_sheetname, row.names = TRUE)
    }
    
    # return summary matrix
    return(this_model_summary)
    
}
