#' Fix Diagnostic List
#'
#' Fix an incomplete diagnostic list by filling in missing elements with NAs
#'
#' @param this_test list object of a seasonal adjustment or modeling diagnostic
#' @param this_names character vector; complete set of names to check against
#' @param this_test list object of a seasonal adjustment or modeling diagnostic
#' @param return_this character string; what the function returns - 'test' returns test results, 'why' returns why the test failed or received a warning, or 'both'
#' @return diagnostic list object with missing names filled in
#' @examples
#' m7_key  <- get_mq_key("M7")
#' @export
fix_diag_list <- function(this_test, this_names, return_this = "both") {
    # Author: Brian C. Monsell (OEUS) Version 1.5, October 2, 2020

    # initialize \code{fixed_list}
    fixed_list <- list()

    # process each list element
    for (i in seq(length(this_names),1,-1)) {
        if (exists(this_names[i], where=this_test)) {
            # if name exists in list, save element into \code{fixed_list}
            fixed_list[[i]] <- this_test[[i]]
        } else {
            # if not, set element to NA or a 1x2 matrix of NAs
            if (return_this == "both") {
                fixed_list[[i]] <- matrix(c(NA,NA), nrow=1)
            } else {
                fixed_list[[i]] <- NA
            }
        }
    }

    # set names for the fixed list, and return
    names(fixed_list) <- this_names
    return(fixed_list)
}
