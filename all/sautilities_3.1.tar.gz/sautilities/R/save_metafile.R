#' Generate X-13ARIMA-SEATS metafile
#'
#' Generates external metafile for spec files generated from a list of \code{seas} objects
#'
#' @param this_seas_list - list of seas objects the metafile will be generated from
#' @param this_name_vec vector of character string; vector of series names from the list of seas objects that will be saved.
#'        Default is all elements of the seasonal object list \code{this_seas_list} are saved.
#' @param metafile_name - character string; base name of metafile to be generated. If not specified, use name of list input as metafile name.
#'        Note - do not specify the \code{".mta"} file extension.
#' @param this_directory - optional directory where the meta file is stored. If not specified, the metafile will be saved in the current working directory.
#' @param include_directory - logical scalar; if TRUE, include directory specified in \code{this_directory} with file name output.
#'        Otherwise, output only names in \code{this_name_vec}. Default is FALSE. Note that the argument \code{this_directory} must also be specified.
#' @return Generates metafile that can be used directly with the X-13ARIMA-SEATS program.
#' @examples
#' xt_lauto <- seasonal::seas(xt_data_list, slidingspans = '', x11 = '',
#'                       arima.model = "(0 1 1)(0 1 1)",
#'                       transform.function = 'log',
#'                       forecast.maxlead=36,
#'                       check.print = c( 'pacf', 'pacfplot' ))
#' \dontrun{save_metafile(xt_lauto, metafile_name = 'xt')}
#' @export
save_metafile <- function(this_seas_list = NULL, this_name_vec = NULL, metafile_name = NULL,
                          this_directory = NULL, include_directory = FALSE) {
    # Author: Brian C. Monsell (OEUS) Version 2.14, 3/25/2022

    # check if a value is specified for \code{this_seas_list}
    if (is.null(this_seas_list)) {
        stop("must specify a list")
    } else {
        if (!is.list(this_seas_list)) {
            stop("must specify a list")
        }
    }

    # Get list names
    if (is.null(this_name_vec)) {
        name_vec <- names(this_seas_list)
    } else {
        name_vec <- this_name_vec
    }

    # set up metafile name to be used to save list names, with directory information if provided
    if (is.null(metafile_name)) {
        file_name <- paste(deparse(substitute(this_seas_list)), ".mta", sep = "")
    } else {
        file_name <- paste(metafile_name, ".mta", sep = "")
    }
    if (!is.null(this_directory)) {
        file_name <- paste(this_directory, file_name, sep = "/")
        if (include_directory) {
            name_vec <- paste(this_directory, name_vec, sep = "/")
        }
    }

    # print out file name
    print(file_name)

    # write out metafile
    write(name_vec, file = file_name)

}
