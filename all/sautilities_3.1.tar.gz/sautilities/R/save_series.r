#' Save Series
#'
#' Save a user-defined regression array or matrix with time series attributes to an external ASCII file in X-13ARIMA-SEATS' datevalue format
#'
#' @param this_series double precision time series array to be saved.
#' @param this_file character string; name of file time series array to be saved to.
#' @return file with user-defined regressors will be produced
#' @examples
#' ukgas_seas <- seasonal::seas(UKgas, series.period = 4, arima.model = '(0 1 1)(0 1 1)', 
#'                              x11='', transform.function = 'log', forecast.maxlead=20, 
#'                              slidingspans = '', check.print = c( 'pacf', 'pacfplot' ))
#' ukgas_sa <- seasonal::final(ukgas_seas)
#' \dontrun{save_series(ukgas_sa, 'ukgas_sa.txt')}
#' @import stats
#' @import utils
#' @export
save_series <- function(this_series, this_file) {
    # Author: Brian C. Monsell (OEUS), Version 1.1, 4/6/2021
    
    # generate time series data matrix with year, month, value
    temp <- cbind(time(this_series)%/%1, cycle(this_series), this_series)
    
    # save data matrix into \code{this_file}
    write.table(temp, this_file, sep = " ", row.names = FALSE, col.names = FALSE)
}
