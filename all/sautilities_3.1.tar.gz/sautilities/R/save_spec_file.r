#' Save spec file representation of \code{seas} object
#'
#' stores the spec file representation of the \code{seas} object \code{this_seas_object} into the file \code{file_name.spc}
#'
#' @param this_seas_object seasonal object
#' @param file_name character string; file name where seas object is stored; default is the name of the seasonal object
#' @param this_directory character string; optional directory where the spec file is stored
#' @param data_file_name character string; optional external file name where data file is stored.
#'        Path should be included with file name if data file is not in working directory; quotes will be added by the routine.
#'        Default is no change in \code{file} entry in the spec file.
#' @param xreg_file_name character string; optional external file name where user defined regressors are stored.
#'        Path should be included with file name if data file is not in working directory; quotes will be added by the routine.
#'        Default is no change in \code{file} entry in the spec file.
#' @param this_title character string; optional custom title; quotes will be added by the routine.
#'        Default is no change in \code{title} entry in the spec file.
#' @return stores the spec file representation of the \code{seas} object \code{this_seas_object} into the file \code{file_name.spc}
#' @examples
#' xt_lauto <- seasonal::seas(xt_data_list, slidingspans = '', transform.function = 'log',
#'                       arima.model = "(0 1 1)(0 1 1)",
#'                       forecast.maxlead=36, check.print = c( 'pacf', 'pacfplot' ))
#' \dontrun{save_spec_file(xt_lauto$us24, 'us24', 
#'                data_file_name = "xtus24mu.dat",
#'                this_title = "Production run for Building Permits for US 2-4 Unit Houses")}
#' @export
save_spec_file <- function(this_seas_object = NULL, file_name = NULL, this_directory = NULL,
                           data_file_name = NULL, xreg_file_name = NULL, this_title = NULL) {
    # Author: Brian C. Monsell (OEUS) Version 3.6, 3/25/2022

    # check if a value is specified for \code{this_seas_object}
    if (is.null(this_seas_object)) {
        stop("must specify a seas object")
    }

    # extract data from the seasonal object \code{this_seas_object}
    x <- this_seas_object$x

    # save static version of object
    #m_static <- seasonal::static(this_seas_object, test = FALSE, x11.filter = TRUE)

    # set up filename to be used to save spec file, with directory information if provided
    if (is.null(file_name)) {
        this_object_name <- deparse(substitute(this_seas_object))
        file_name <- paste(this_object_name, ".spc", sep = "")
    } else {
        file_name <- paste(file_name, ".spc", sep = "")
    }
    if (!is.null(this_directory)) {
        file_name <- paste(this_directory, file_name, sep = "/")
    }

    this_spc <- seasonal::spc(this_seas_object)
    if (!is.null(this_title)) {
        this_spc$series$title <- paste0("\"", this_title, "\"")
    }
    if (!is.null(data_file_name)) {
        this_spc$series$file <- paste0("\"", data_file_name, "\"")
    }
    if (!is.null(xreg_file_name)) {
        this_spc$regression$file <- paste0("\"", xreg_file_name, "\"")
    }

    # print out file name
    print(file_name)

    # use sink to store X-13 specs to file
    sink(file_name)
    print(this_spc)
    sink()

}
