#' Update Diagnostic Matrix
#'
#' Update the matrix of diagnostics used to generate the diagnostic data frame in \code{make_diag_df}
#'
#' @param this_diag_list list object with elements for seasonal adjustment or modeling diagnostic, titles, and the number of columns
#' @param this_test_list list object of a specific seasonal adjustment or modeling diagnostic
#' @param this_label character string; name of diagnostic in \code{this_test_list} 
#' @return list object with updated elements for seasonal adjustment or modeling diagnostic, titles, and the number of columns
#' @examples
#' test_lauto <- seasonal::seas(xt_data_new,
#'            x11 = '', slidingspans = '',
#'            arima.model = "(0 1 1)(0 1 1)",
#'            transform.function = 'log',
#'            forecast.maxlead=60,
#'            check.print = c( 'pacf', 'pacfplot' ))
#' test_acf <- lapply(test_lauto, function(x) try(acf_test(x, return_this = 'both')))
#' test_names <- names(xt_data_new)
#' num_names <- length(test_names)
#' all_diag_list <- list(n = 0, diag = 0, titles = 0)
#' if (!is.null(test_acf)) {
#'     if (length(test_acf) < num_names) {
#'         this_acf_test <- fix_diag_list(test_acf, test_names, return_this = 'both')
#'     }
#'     all_diag_list <- 
#'         update_diag_matrix(all_diag_list, test_acf, "ACF")
#' }
#' @export
update_diag_matrix <- function(this_diag_list, this_test_list, this_label) {
    # Author: Brian C. Monsell (OEUS) Version 3.4, 3/25/2022
    
    # load tests into matrix
    this_test_matrix <- matrix(unlist(this_test_list), nrow = length(this_test_list), 
                               byrow = TRUE)
    
    # set diagnostic matrix and titles
    if (this_diag_list$n > 0) {
        this_diag_list$diag <- cbind(this_diag_list$diag, this_test_matrix)
        this_diag_list$titles <- c(this_diag_list$titles, this_label)
    } else {
        this_diag_list$diag <- this_test_matrix
        this_diag_list$titles <- this_label
    }
    if (ncol(this_test_matrix) > 1) {
        this_diag_list$titles <- c(this_diag_list$titles, paste(this_label, "fail?"))
    }
    
    # Update number of columns in data frame
    this_diag_list$n <- this_diag_list$n + ncol(this_test_matrix)
    
    return(this_diag_list)
}
