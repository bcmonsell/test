#' Check list for try errors 
#'
#' Checks list for try errors, returning element names with errors 
#'
#' @param this_list list object which potentially contains 'try-error' class objects.  
#' @return vector of the names of list elements that are 'try-error' class objects. If the list contains no 'try-error' class objects, the function will return NULL
#' @examples
#' xt_lauto <- 
#'   seasonal::seas(xt_data_list, slidingspans = '', transform.function = 'log',
#'                               forecast.maxlead=36, arima.model = '(0 1 1)(0 1 1)',
#'                               check.print = c( 'pacf', 'pacfplot' ))
#' xt_lauto_errors <- which_error(xt_lauto) 
#' @import stats
#' @export
which_error <- function(this_list = NULL) {
    # Author: Brian C. Monsell (OEUS) Version 2.7, 3/25/2022
    
    # check if a value is specified for \code{this_list}
    if (is.null(this_list)) {
        stop("must specify a list of seas objects")
    } else {
        if (!is.list(this_list)) {
            stop("must specify a list")
        }
    }
    
    # get names of elements with try-errors
    this_error <- lapply(this_list, function(x) try(inherits(x, "try-error")))
    this_error_names <- names(this_list)[unlist(this_error)]
    
    # return names or 'none' if no errors
    if (length(this_error_names) > 0) {
        return(this_error_names)
    } else {
        return(NULL)
    }
}
